
<!--===============================================================================================-->
	<script src="<?= base_url('login/') ?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="<?= base_url('login/') ?>vendor/bootstrap/js/popper.js"></script>
	<script src="<?= base_url('login/') ?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	
    
	<script src="<?= base_url() ?>vendors/pnotify/dist/pnotify.js"></script>
    <script src="<?= base_url() ?>vendors/pnotify/dist/pnotify.buttons.js"></script>
    <script src="<?= base_url() ?>vendors/pnotify/dist/pnotify.nonblock.js"></script>

	<script src="<?= base_url('login/') ?>js/main.js"></script>
	<script>
		
	</script>
    <script src="<?= base_url() ?>build/js/alert.js"></script>
	<style>
      .ui-pnotify{
        width: 250px;
      }
    </style>

</body>
</html>
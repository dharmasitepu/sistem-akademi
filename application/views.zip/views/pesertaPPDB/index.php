<div class="right_col" role="main" style="min-height: 2098px;">
    <?php if ($this->session->flashdata('berhasil')) { ?>
      <div class="flash-data" data-flashdata="<?= $this->session->flashdata('berhasil'); ?>" data-tipe="Berhasil"
      data-judul="Data Mapel"></div>
    <?php } if ($this->session->flashdata('gagal')) { ?>
    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('gagal'); ?>" data-tipe="Gagal"
      data-judul="Data Mapel"></div>
    <?php } ?>
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                    <h2>Dashboard</h2>
                    <div class="clearfix"></div>
                    <h2>INFORMASI</h2>
                    </div>
                    <div class="x_content" style="display: block;">
                        <div class="well" style="overflow: auto">
                        <h2>Halo, <strong><?= $user['username'] ?></strong></h2><p>Silahkan melakukan pembayaran pendaftaran, melaluhi transfer ke BPD BALI<br> No. Rek : 0370202004023<br> a.n SMK TI BALI GLOBAL DENPASAR</p> 
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <h2>INFORMASI</h2>
                        <div class="clearfix"></div>
                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                        
                        <div class="x_panel tile fixed_height_320">
                        
                            <div class="x_content">
                            
                            <br>
                            Dimohon untuk rajin login disini karena pengumuman bisa berubah sewaktu-waktu.<br>Like/follow Social Media (Facebook/Instagram/Twitter) SMK TI Bali Global Denpasar untuk memperoleh informasi terupdatekami.<br>Bagi anda yang belum daftar ulang, silahkan melakukan daftar ulang.<br><br>Cara Daftar Ulang:<br><ol><li>Ambil dan isi formulir daftar ulang di petugas pendaftaran di Lobi.<br></li><li>Melakukan pembayaran minimal 50% DPP dan uang seragam</li><li>Setelah selesai melakukan pembayaran, serahkan kembali formulir daftar ulang ke petugas pendaftaran.</li></ol><br>          

                            </div>
                        </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <h2>PENGUMUMAN</h2>
                        <div class="clearfix"></div>
                        </div>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel tile fixed_height_320">
                        
                            <div class="x_content">
                                        <br>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    

    
